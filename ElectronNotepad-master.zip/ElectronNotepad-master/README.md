<h1 align="center" >Simple Notepad like desktop application</h1>
<h3 align="center">Currently supports single file edit, user can open recent opened file</h3>

[![forthebadge](https://forthebadge.com/images/badges/uses-js.svg)](http://forthebadge.com)

<br>


## Tools used
* Electron.JS

<br>

## Author

### [Sankhadip Samanta](https://github.com/dev-sankhadip) ❤

[<img src="https://image.flaticon.com/icons/svg/185/185964.svg" width="35" padding="10">](https://www.linkedin.com/in/sankhadip-samanta-7bb891180)